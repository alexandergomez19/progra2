package service;

import java.util.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import javax.swing.JOptionPane;

public class Main {

	public static void main(String[] args) {
		//
		String menu= "alexander.gomez3@ulatina.net\n1. Establecer la secuencia Fibonacci\n2. Sumar días a una fecha indicada por el usuario\n3. Salir\n";
		int opcion=0;
		do {
			try {
				opcion=Integer.parseInt(JOptionPane.showInputDialog(menu+"ingrese la opción que desea ejecutar: "));
				switch(opcion) {
				case 1:
					secuenciaFibonacci(args);
					break;
				case 2:
					sumarDias(args);
					break;
				case 3:
					JOptionPane.showMessageDialog(null, "saliendo","chaitooooooooooooooooooooooooo",JOptionPane.INFORMATION_MESSAGE);
					break;
					}
			}catch(NumberFormatException e) {
				JOptionPane.showMessageDialog(null, "por favor ingrese unicamente numeros mostrados en el menú","cuidado",JOptionPane.WARNING_MESSAGE);
			}
		}while(opcion!=3);
	}
	
	public static void secuenciaFibonacci(String[] args) {
		try {
			int rango= Integer.parseInt(JOptionPane.showInputDialog("ingrese la extención que desea para la sucesión Fibonacci: "));
			int suma1=1;
			int suma2;
			
			String posicion="0,1,";
			for (int i=2;i<rango+1;i++) {
				suma2= suma1;
				suma1=suma2;
				posicion +=suma1 + " ";
			}
			JOptionPane.showMessageDialog(null, posicion);
		}catch(NumberFormatException e) {
			JOptionPane.showMessageDialog(null, "por favor ingrese unicamente numeros","cuidado",JOptionPane.WARNING_MESSAGE);
		}
	}
	public static void sumarDias(String[] args) {
		try {
			
			try {
				SimpleDateFormat sdf= new SimpleDateFormat("dd/MM/yyyy");
				String fechaUser=JOptionPane.showInputDialog("ingrese la fecha a la que desea añadirle días");
				Date fechaDate = sdf.parse(fechaUser);
				int dias=Integer.parseInt(JOptionPane.showInputDialog("ingrese el numero de dias que desea añadir: "));
				
				JOptionPane.showMessageDialog(null, "la fecha "+fechaDate+", sumandole "+dias+" dias, es: ");
			}catch(ParseException e) {
				JOptionPane.showMessageDialog(null, "no se ingresó la fecha de manera adecuada","cuidado",JOptionPane.WARNING_MESSAGE);
			};
		}catch(NumberFormatException e){
			JOptionPane.showMessageDialog(null, "por favor ingrese unicamente numeros","cuidado",JOptionPane.WARNING_MESSAGE);
		}
	}
}
