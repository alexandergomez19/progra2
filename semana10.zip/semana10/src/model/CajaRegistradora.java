package model;

public class CajaRegistradora {
	private static CajaRegistradora caja;
	private static int totalPago;
	
	private CajaRegistradora() {
		
	}
	public static CajaRegistradora getCajaRegistradora() {
		if (CajaRegistradora.caja==null) {
			caja= new CajaRegistradora();
			totalPago=0;
		}
		return CajaRegistradora.caja;
	} 
	public static CajaRegistradora getCaja() {
		return caja;
	}
	public static void setCaja(CajaRegistradora caja) {
		CajaRegistradora.caja = caja;
	}
	public static int getTotalPago() {
		return totalPago;
	}
	public static void setTotalPago(int totalPago) {
		CajaRegistradora.totalPago = totalPago;
	}
	
}
