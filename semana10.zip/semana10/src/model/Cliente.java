package model;

public class Cliente {
	private String nombre;
	private int cedula;
	private Membresia membresia;
	public Cliente(String nombre, int cedula, Membresia membresia) {
		super();
		this.nombre = nombre;
		this.cedula = cedula;
		this.membresia = membresia;
	}
	
	public String getNombre() {
		return nombre;
	}


	public void setNombre(String nombre) {
		this.nombre = nombre;
	}


	public int getCedula() {
		return cedula;
	}


	public void setCedula(int cedula) {
		this.cedula = cedula;
	}


	public Membresia getMembresia() {
		return membresia;
		
	}


	public void setMembresia(Membresia membresia) {
		this.membresia = membresia;
	}


	public void obtenerBeneficios() {
		this.membresia.obtenerBeneficios();
	}
	
	
	
}
