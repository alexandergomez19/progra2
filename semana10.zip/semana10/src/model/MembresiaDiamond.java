package model;

import javax.swing.JOptionPane;

public class MembresiaDiamond implements Membresia{

	@Override
	public void obtenerBeneficios() {
		String benefcios = "Decuentos, Acceso al lugar";
		JOptionPane.showMessageDialog(null, benefcios);
		
	}

	@Override
	public int obtenerPorcentaje() {
		// TODO Auto-generated method stub
		return 25;
	}
	
}
