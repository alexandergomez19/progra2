package model;

import javax.swing.JOptionPane;

public class MembresiaPlatino implements Membresia{

	@Override
	public void obtenerBeneficios() {
		// TODO Auto-generated method stub
		String benefcios = "Decuentos, Acceso al lugar, spam, regalias";
		JOptionPane.showMessageDialog(null, benefcios);
	}
	@Override
	public int obtenerPorcentaje() {
		// TODO Auto-generated method stub
		return 4;
	}
}
