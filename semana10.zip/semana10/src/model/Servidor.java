package model;

public class Servidor {
	private static Servidor servidor;
	private static String ip;
	private static String user;
	private static String dataBase;
	private static String pass;
	
	private Servidor() {
		
	}
	public static Servidor getServidor() {
		if (Servidor.servidor==null) {
			servidor = new Servidor();
			ip="127.0.0.1";
			dataBase="127.0.0.1/database";
			user="alexelcapo";
			pass="12345";
		}
			
			return Servidor.servidor;
			
	}
	public static String getIp() {
		return ip;
	}
	public static void setIp(String ip) {
		Servidor.ip = ip;
	}
	public static String getUser() {
		return user;
	}
	public static void setUser(String user) {
		Servidor.user = user;
	}
	public static String getDataBase() {
		return dataBase;
	}
	public static void setDataBase(String dataBase) {
		Servidor.dataBase = dataBase;
	}
	public static String getPass() {
		return pass;
	}
	public static void setPass(String pass) {
		Servidor.pass = pass;
	}
	public static void setServidor(Servidor servidor) {
		Servidor.servidor = servidor;
	}
	
	
	
}
