package service;

import javax.swing.JOptionPane;

import model.Servidor;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Servidor serverchavales = Servidor.getServidor();
		JOptionPane.showMessageDialog(null, serverchavales.getDataBase()+"\n "+serverchavales.getIp()+"\n "+serverchavales.getUser()+"\n "+serverchavales.getPass());
		
		Servidor serv2 = Servidor.getServidor()	;
		JOptionPane.showMessageDialog(null, serv2.getDataBase()+serv2.getIp());
		}

}
