package service;

public class MainSingleton {
	
	public static void main(String[] args) {
		
	}
	
}
