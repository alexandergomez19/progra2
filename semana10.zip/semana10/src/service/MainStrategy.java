package service;

import javax.swing.JOptionPane;

import model.Cliente;
import model.MembresiaDiamond;

public class MainStrategy {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		MembresiaDiamond diamond = new MembresiaDiamond();
		String nombre= JOptionPane.showInputDialog("ingrese un nombre");
		int cedula=Integer.parseInt(JOptionPane.showInputDialog("ingrese su numero de cedula"));
		
		Cliente cliente = new Cliente(nombre,cedula,diamond);
		cliente.obtenerBeneficios();
		
		
		
	}

}
