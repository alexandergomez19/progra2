package model;

public class Calculadora {
	public int sumar(int a, int b) {
		return a+b;
	}
	public int resta(int a, int b) {
		return a-b;
	}
	public int multi(int a, int b) {
		return a*b;
	}
	public int division(int a, int b) {
		return a/b;
	}
}
