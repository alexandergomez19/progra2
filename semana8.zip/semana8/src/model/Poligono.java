package model;

public class Poligono {

}
