package test;

import static org.junit.Assert.assertEquals;
import org.junit.jupiter.api.Test;
import model.Calculadora;

class CalculadoraTest {
		

	@Test
	void testSumar() {
		Calculadora calc = new Calculadora();
		int result = calc.sumar(5, 3);
		assertEquals(8,result);
	}
	@Test
	void testRestar() {
		Calculadora calc = new Calculadora();
		int result = calc.resta(5, 3);
		assertEquals(2,result);
	}
	@Test
	void testMulti() {
		Calculadora calc = new Calculadora();
		int result = calc.multi(5, 3);
		assertEquals(15,result);
	}
	@Test
	void testDividir() {
		Calculadora calc = new Calculadora();
		int result = calc.division(5, 3);
		assertEquals(1,result);
	}

}
