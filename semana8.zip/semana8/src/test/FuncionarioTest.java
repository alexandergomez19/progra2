package test;

import static org.junit.Assert.assertTrue;
import javax.swing.JOptionPane;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import model.Funcionario;

class FuncionarioTest {
	static Funcionario funcionario;
	int a;
	int b;
	
	@BeforeAll
	static void starter() throws Exception {
		JOptionPane.showMessageDialog(null, "inicializando variable funcionario");
		funcionario = new Funcionario();
	}
	
	@BeforeEach
	void starterVariables() throws Exception {
		a=0;
		b=0;
	}
	
	@Test
	void testMayor() {
		JOptionPane.showMessageDialog(null, "test mayor");
		a= Integer.parseInt(JOptionPane.showInputDialog("Ingrese un numero"));
		b= Integer.parseInt(JOptionPane.showInputDialog("Ingrese otro numero"));
		assertTrue("Num 1 no es mayor que Num2 ",funcionario.esMayor(a, b));
	}
	@Test
	void testMenor() {
		JOptionPane.showMessageDialog(null, "test menor");
		a= Integer.parseInt(JOptionPane.showInputDialog("Ingrese un numero"));
		b= Integer.parseInt(JOptionPane.showInputDialog("Ingrese otro numero"));
		assertTrue("Num 1 no es menor que Num2 ",funcionario.esMenor(a, b));
	}
	@Test
	void testIgual() {
		JOptionPane.showMessageDialog(null, "test igual");
		a= Integer.parseInt(JOptionPane.showInputDialog("Ingrese un numero"));
		b= Integer.parseInt(JOptionPane.showInputDialog("Ingrese otro numero"));
		assertTrue("Num 1 no es igual que Num2 ",funcionario.esIgual(a, b));
	}
	@AfterEach
	void testFinish() throws Exception{
		JOptionPane.showMessageDialog(null, "valor A: "+a+" Valor B: "+b );
	}
	@AfterAll
	static void finish() throws Exception{
		JOptionPane.showMessageDialog(null, "fin del test");
	} 
}
