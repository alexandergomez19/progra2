package test;



import org.junit.jupiter.api.Test;

class PoligonosTest {

	@Test
	void testCuadrados() {
		
	}

}
