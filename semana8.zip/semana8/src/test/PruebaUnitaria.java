package test;

import static org.junit.jupiter.api.Assertions.*;

import javax.swing.JOptionPane;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class PruebaUnitaria {
	static int contador =0;
	@BeforeAll
	static void metodoBA() throws Exception{
		JOptionPane.showConfirmDialog(null, "Iniciando Prueba");
	}
	
	@BeforeEach
	void metodoBE() throws Exception{
		contador++;
		JOptionPane.showConfirmDialog(null, "ejecutando prueba "+contador);
	}
	
	@Test
	void test1() {
		fail("ejecutado test1 ");
	}
	
	@Test
	void test2() {
		fail("ejecutado test2 ");
	}
	
	@AfterEach
	void metodoAE() throws Exception{
		JOptionPane.showConfirmDialog(null, "finalizando prueba  "+contador);
	}
	
	
	@AfterAll
	static void metodoAfterAll() throws Exception{
		JOptionPane.showConfirmDialog(null, "finaizando Prueba");
	}
	
}
