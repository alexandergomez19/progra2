package model;

public class Producto {
	
	private String marca;
	private int stock;
	private String categoria;
	
	public Producto() {}

	public Producto(String marca, int stock, String categoria) {
		super();
		this.marca = marca;
		this.stock = stock;
		this.categoria = categoria;
	}

	public String getMarca() {
		return marca;
	}

	public void setMarca(String marca) {
		this.marca = marca;
	}

	public int getStock() {
		return stock;
	}

	public void setStock(int stock) {
		this.stock = stock;
	}

	public String getCategoria() {
		return categoria;
	}

	public void setCategoria(String categoria) {
		this.categoria = categoria;
	}
	
	
}
