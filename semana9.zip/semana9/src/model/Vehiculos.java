package model;

public class Vehiculos {
	private int numPlaca;
	private String marca;
	private boolean rtve= false;
	
	
	public Vehiculos() {
		
	}

	public Vehiculos(int numPlaca, String marca, boolean rtve, String datos) {
		super();
		this.numPlaca = numPlaca;
		this.marca = marca;
		this.rtve = rtve;
		
	}

	public int getNumPlaca() {
		return numPlaca;
	}

	public void setNumPlaca(int numPlaca) {
		this.numPlaca = numPlaca;
	}

	public String getMarca() {
		return marca;
	}

	public void setMarca(String marca) {
		this.marca = marca;
	}

	public boolean isRtve() {
		return rtve;
	}

	public void setRtve(boolean rtve) {
		this.rtve = rtve;
	}
	
	
	
}
