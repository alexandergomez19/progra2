package service;

import javax.swing.JOptionPane;

import model.Producto;
import model.Vehiculos;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String menu = " 1. Agregar vehiculos en un vector \n"
				+ " 2. Mostrar los vehiculos del vector\n"
				+ " 3. Agregar productos a una lista \n"
				+ " 4. Mostrar los productos de la lista \n "
				+ " 5. Eliminar productos de la lista \n"
				+ " 6. Modificar productos de la lista \n"
				+ " 7. Salir";
		int opcion=0;
		int tamanoVector=Integer.parseInt(JOptionPane.showInputDialog("ingrese el tamaño del vector"));
		Vehiculos vehiculo[] = new Vehiculos[tamanoVector];
		
		do {
			try {
				
				
				opcion=Integer.parseInt(JOptionPane.showInputDialog(menu));
				switch(opcion) {
				case 1:
					for (int i= 0 ; i < vehiculo.length; i++) {
					vehiculo[i].setMarca(JOptionPane.showInputDialog("ingrese la marca del vehiculo: "));
					vehiculo[i].setNumPlaca(Integer.parseInt(JOptionPane.showInputDialog("ingrese la placa del vehiculo: ")));
					vehiculo[i].setRtve(Boolean.parseBoolean(JOptionPane.showInputDialog("tiene rtve al dia? si/True-no/False: ")));
				}
					
					
					break;
				case 2:
					for (int i= 0 ; i < vehiculo.length; i++) {
						if (vehiculo[i] != null){
							JOptionPane.showMessageDialog(null, "vehiculo "+(i+1)+": "+vehiculo[i]);
						}
						}
					break;
				case 3:
					Lista<Producto> prod 
					Producto producto=new Producto();
					producto.setMarca(JOptionPane.showInputDialog("ingrese la marca del producto: "));
					producto.setCategoria(JOptionPane.showInputDialog("ingrese la placa del vehiculo: "));
					producto.setStock(Integer.parseInt(JOptionPane.showInputDialog("ingrese la placa del vehiculo: ")));
					
					productos.add(producto);
					break;
				default:
					break;
				}
				
			}catch(NumberFormatException e) {
				JOptionPane.showMessageDialog(null, "ingrese un numero valido porfi","ERRRRRRRRRRRRRORRRRRRRR",JOptionPane.WARNING_MESSAGE);
			};
		}while(opcion !=7);
		
	}

	public static void agregarVehiculos() {
		
	}
	
}
